(() => {
  'use strict';
  const q = new URLSearchParams(location.search);
  const req = q.get('req') || '';
  const origin = q.get('origin') || '';
  document.getElementById('origin').textContent = origin;
  let sent = false;
  const decide = async (decision) => {
    if (sent) return;
    sent = true;
    let d = decision;
    let reason;
    if (d !== 'deny') {
      // Xin quyền truy cập trang NGAY trong cú bấm này (cần cử chỉ người dùng). Đã có quyền thì trả về true mà không hỏi lại.
      // (Mẫu quyền không có cổng; việc duyệt của extension vẫn theo origin đầy đủ.)
      try {
        const u = new URL(origin);
        const granted = await chrome.permissions.request({ origins: [u.protocol + '//' + u.hostname + '/*'] });
        if (!granted) { d = 'deny'; reason = 'Chrome không cấp quyền truy cập trang (bạn đã từ chối hộp thoại của Chrome?)'; }
      } catch (e) { d = 'deny'; reason = String((e && e.message) || e); }
    }
    // Chờ service worker xác nhận đã ghi quyết định rồi mới đóng cửa sổ (đóng sớm từng bị hiểu nhầm là "từ chối").
    try { await chrome.runtime.sendMessage({ type: 'nd-bridge-decision', req, decision: d, reason }); } catch (e) { /* service worker vừa khởi động lại: đóng vẫn an toàn */ }
    window.close();
  };
  document.getElementById('once').addEventListener('click', () => decide('once'));
  document.getElementById('always').addEventListener('click', () => decide('always'));
  document.getElementById('deny').addEventListener('click', () => decide('deny'));
})();
