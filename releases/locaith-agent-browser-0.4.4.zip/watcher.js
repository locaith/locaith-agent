﻿(() => {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const tabId = Number(new URLSearchParams(location.search).get('tabId'));
  const call = (op, extra) => chrome.runtime.sendMessage({ type: 'nd-watch-api', op, tabId, ...extra });
  const mode = () => document.querySelector('input[name=mode]:checked').value;
  let origin = '';

  function sync() {
    $('sendwarn').classList.toggle('hide', mode() !== 'send');
    $('aiopts').classList.toggle('hide', mode() === 'notify');
    $('selwrap').classList.toggle('hide', $('signal').value !== 'selector');
  }
  document.querySelectorAll('input[name=mode]').forEach((r) => r.addEventListener('change', sync));
  $('signal').addEventListener('change', sync);

  function fill(c) {
    document.querySelector(`input[name=mode][value=${c.mode}]`).checked = true;
    $('ins').value = c.instruction || '';
    $('signal').value = c.signal;
    $('sel').value = c.selector || '';
    $('gap').value = c.minGapSec; $('cap').value = c.maxPerHour; $('exp').value = c.expireHours;
    sync();
  }

  function showStatus(c) {
    const on = !!c;
    $('off').classList.toggle('hide', !on);
    $('go').textContent = on ? 'Lưu & áp dụng lại' : 'Bắt đầu theo dõi';
    $('st').classList.toggle('hide', !on);
    if (on) {
      $('st').textContent =
        `Đang theo dõi từ ${new Date(c.since).toLocaleTimeString('vi-VN')}\n` +
        `Tín hiệu đã nhận: ${c.stat.events} · Lượt trợ lý trong 1 giờ qua: ${c.stat.runs.filter((t) => Date.now() - t < 3600e3).length}/${c.maxPerHour}\n` +
        (c.stat.lastNote || '');
    }
  }

  let first = true;
  async function refresh() {
    const r = await call('get');
    if (!r || !r.ok) { $('tabinfo').textContent = 'Không tìm thấy tab (có thể đã đóng).'; $('go').disabled = true; return; }
    $('tabinfo').textContent = (r.tab.title || '(không có tiêu đề)') + (r.tab.url ? ' — ' + r.tab.url : '');
    try { origin = r.tab.url ? new URL(r.tab.url).origin : ''; } catch (e) { origin = ''; }
    if (r.cfg && first) fill(r.cfg);
    if (!r.cfg && first) { try { const p = JSON.parse(new URLSearchParams(location.search).get('prefill') || 'null'); if (p) fill({ mode: 'notify', signal: 'auto', minGapSec: 30, maxPerHour: 10, expireHours: 8, ...p }); } catch (e) {} }
    first = false;
    showStatus(r.cfg);
  }

  $('go').addEventListener('click', async () => {
    $('err').textContent = '';
    if (mode() === 'send' && !$('ack').checked) { $('err').textContent = 'Hãy tick ô xác nhận trước khi bật chế độ tự gửi.'; return; }
    if (mode() !== 'notify' && !$('ins').value.trim() && !confirm('Chưa có hướng dẫn trả lời. Trợ lý sẽ tự quyết giọng văn. Vẫn tiếp tục?')) return;
    // Xin quyền phải gọi trước mọi await khác (cử chỉ người dùng).
    const origins = origin && /^https?:/.test(origin) ? [origin + '/*'] : ['<all_urls>'];
    try {
      const has = await chrome.permissions.contains({ origins });
      if (!has && !(await chrome.permissions.request({ origins }))) {
        $('err').textContent = 'Cần quyền truy cập trang này để theo dõi sau khi trang tải lại.'; return;
      }
    } catch (e) { /* tiếp tục; activeTab có thể đủ cho lần đầu */ }
    const r = await call('start', {
      cfg: {
        mode: mode(), instruction: $('ins').value, signal: $('signal').value, selector: $('sel').value,
        minGapSec: $('gap').value, maxPerHour: $('cap').value, expireHours: $('exp').value,
      },
    });
    if (!r || !r.ok) { $('err').textContent = (r && r.error) || 'Không bắt đầu được.'; return; }
    await refresh();
  });

  $('off').addEventListener('click', async () => { await call('stop'); location.reload(); });

  refresh();
  setInterval(refresh, 5000);
})();

