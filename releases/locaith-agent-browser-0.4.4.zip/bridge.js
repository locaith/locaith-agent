(() => {
  'use strict';
  const PORTS = [47615, 47616, 47617, 47618, 47619, 47620];
  const KEY = 'nd.bridge';
  const $ = (id) => document.getElementById(id);
  const send = (m) => chrome.runtime.sendMessage(m);
  const say = (t, cls) => { $('msg').className = cls || ''; $('msg').textContent = t; };

  async function refresh() {
    const st = await send({ type: 'nd-bridge-status' });
    try {
      const has = await chrome.permissions.contains({ origins: ['<all_urls>'] });
      $('shotState').textContent = has ? 'Đang bật' : 'Đang tắt';
      $('shot').textContent = has ? 'Tắt chụp màn hình' : 'Cho phép chụp màn hình';
    } catch (e) { /* bỏ qua */ }
    $('pairBox').hidden = !!st.paired;
    $('doneBox').hidden = !st.paired;
    $('state').textContent = st.paired ? 'Đang chờ lệnh từ VS Code' + (st.ports.length ? ' (cổng ' + st.ports.join(', ') + ')' : '') + '. Chỉ trang bạn cho phép mới được thao tác.' : '';
    const all = [...new Set([...(st.allowed || []), ...(st.session || [])])];
    $('noAllowed').hidden = all.length > 0;
    const ul = $('allowed');
    ul.textContent = '';
    for (const o of all) {
      const li = document.createElement('li');
      li.className = 'row';
      const s = document.createElement('span');
      s.textContent = o + ((st.allowed || []).includes(o) ? '' : ' (chỉ phiên này)');
      const b = document.createElement('button');
      b.className = 'alt';
      b.textContent = 'Thu hồi';
      b.onclick = async () => {
        await send({ type: 'nd-bridge-forget', origin: o });
        // Thu hồi luôn quyền trang của Chrome — trừ khi còn một origin khác (khác cổng) cùng tên miền đang được cho phép.
        try {
          const u = new URL(o);
          const rest = all.filter((x) => x !== o && new URL(x).hostname === u.hostname);
          if (rest.length === 0) await chrome.permissions.remove({ origins: [u.protocol + '//' + u.hostname + '/*'] });
        } catch (e) { /* không thu hồi được: không sao, danh sách duyệt đã xoá */ }
        refresh();
      };
      li.append(s, b);
      ul.append(li);
    }
  }

  $('pair').addEventListener('click', async () => {
    const code = $('code').value.trim();
    if (!/^[A-Za-z0-9]{4}-?[A-Za-z0-9]{4}$/.test(code)) return say('Mã gồm 8 ký tự, ví dụ ABCD-EFGH.', 'err');
    $('pair').disabled = true;
    say('Đang ghép đôi…');
    try {
      // Xin quyền "tabs" TRƯỚC (cần cử chỉ người dùng); nếu từ chối vẫn ghép đôi được nhưng danh sách tab sẽ hạn chế.
      let tabs = true;
      try { tabs = await chrome.permissions.request({ permissions: ['tabs'] }); } catch (e) { tabs = false; }
      let result = null;
      let sawServer = false;
      for (const p of PORTS) {
        try {
          const r = await fetch('http://127.0.0.1:' + p + '/v1/pair', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ code }) });
          sawServer = true;
          if (r.ok) { result = await r.json(); break; }
          const j = await r.json().catch(() => ({}));
          if (j.error === 'bad_code') return say('Mã không đúng. Kiểm tra lại mã trong VS Code.', 'err');
        } catch (e) { /* cổng này không có máy chủ */ }
      }
      if (!result) return say(sawServer ? 'VS Code chưa ở chế độ ghép đôi (hoặc mã đã hết hạn). Bấm "Tạo mã ghép đôi" trong Chợ → Chrome rồi thử lại.' : 'Không thấy VS Code. Mở VS Code, bật "Chrome" trong Chợ rồi thử lại.', 'err');
      await chrome.storage.local.set({ [KEY]: { token: result.token } });
      await send({ type: 'nd-bridge-start' });
      say('Đã ghép đôi thành công.' + (tabs ? '' : '\nLưu ý: bạn đã từ chối quyền "tabs" nên trợ lý chỉ thấy tên miền của các tab.'), 'ok');
      $('code').value = '';
      refresh();
    } finally {
      $('pair').disabled = false;
    }
  });
  $('shot').addEventListener('click', async () => {
    try {
      const has = await chrome.permissions.contains({ origins: ['<all_urls>'] });
      if (has) await chrome.permissions.remove({ origins: ['<all_urls>'] });
      else await chrome.permissions.request({ origins: ['<all_urls>'] }); // cần cử chỉ người dùng: gọi ngay trong cú bấm
    } catch (e) { say('Không đổi được quyền: ' + String((e && e.message) || e), 'err'); }
    refresh();
  });
  $('unpair').addEventListener('click', async () => { await send({ type: 'nd-bridge-stop' }); say('Đã ngắt kết nối. Nhớ bấm "Huỷ ghép đôi" trong VS Code nếu muốn thu hồi hẳn.', 'ok'); refresh(); });
  refresh();
  setInterval(refresh, 4000);
})();
