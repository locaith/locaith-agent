// Locaith AI — Cầu nối VS Code (service worker). Nạp bằng importScripts ở cuối background.js.
// Extension là bên CHỦ ĐỘNG gọi vào máy chủ cầu của VS Code (127.0.0.1, long-poll), nhận lệnh, làm trên tab rồi trả kết quả.
// An toàn: mọi thao tác trên một trang cần người dùng duyệt NGAY TRONG CHROME theo từng trang (origin); danh sách tab chỉ lộ tên miền của trang chưa duyệt.
(() => {
  'use strict';
  const PORTS = [47615, 47616, 47617, 47618, 47619, 47620];
  const KEY = 'nd.bridge';
  const ON = 'nd.bridge.on'; // công tắc «VS Code» trong khung chat: false = người dùng đã tắt (giữ token để bật lại là nối ngay); thiếu = bật (bản cũ chỉ cần có token)
  const ALLOW = 'nd.bridge.allow';
  const ALARM = 'nd-bridge-tick';
  const MENU = 'nd-bridge-menu';
  const APPROVE_MS = 150000;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const loops = new Set();
  const pending = new Map(); // origin -> Promise<decision>
  const waiting = new Map(); // req -> { origin, done }
  let token = '';
  let running = false;
  let lastOkAt = 0; // lần gần nhất một cổng VS Code trả lời hợp lệ: «đã kết nối» = trong vòng 45 giây

  async function loadToken() {
    const o = await chrome.storage.local.get(KEY);
    token = (o[KEY] && o[KEY].token) || '';
    return token;
  }

  const isOn = async () => (await chrome.storage.local.get(ON))[ON] !== false;
  const connected = () => running && Date.now() - lastOkAt < 45000;

  async function start() {
    if (!(await loadToken())) return false;
    if (!(await isOn())) return false;
    running = true;
    for (const p of PORTS) if (!loops.has(p)) void pollLoop(p);
    chrome.alarms.create(ALARM, { periodInMinutes: 0.5 });
    return true;
  }

  function stop() {
    running = false;
    chrome.alarms.clear(ALARM);
  }

  async function pollLoop(port) {
    loops.add(port);
    let miss = 0;
    try {
      // Kiểm tra nhanh xem cổng này có VS Code đã ghép với ta không: long-poll chỉ trả lời sau tối đa 20 giây, nên nếu không có bước này thì công tắc báo «đang tìm VS Code» cả 20 giây đầu.
      try {
        const r = await fetch(`http://127.0.0.1:${port}/v1/ping`, { headers: { authorization: 'Bearer ' + token } });
        if (r.ok) lastOkAt = Date.now();
      } catch (e) {
        /* cổng này chưa có VS Code */
      }
      while (running && token) {
        try {
          // Gọi một API tiện ích mỗi vòng: đặt lại bộ đếm nhàn rỗi để service worker không bị tắt khi đang chờ lệnh.
          chrome.runtime.getPlatformInfo(() => void chrome.runtime.lastError);
          const r = await fetch(`http://127.0.0.1:${port}/v1/poll?wait=20`, { headers: { authorization: 'Bearer ' + token } });
          if (r.ok) {
            miss = 0;
            lastOkAt = Date.now();
            const j = await r.json();
            if (j && j.job) void run(port, j.job);
            continue;
          }
          miss = r.status === 401 ? 6 : miss + 1; // 401: cửa sổ VS Code này không biết token của ta (ghép đôi khác) — thử lại thưa
        } catch (e) {
          miss++;
        }
        await sleep(Math.min(8000, 1000 + miss * 1000)); // ngắn: cửa sổ VS Code khác có thể vừa mở một cổng mới
      }
    } finally {
      loops.delete(port);
    }
  }

  async function run(port, job) {
    let out;
    try {
      const fn = OPS[job.op];
      if (!fn) throw new Error('Lệnh không được hỗ trợ: ' + job.op);
      out = { ok: true, data: await fn(job.args || {}) };
    } catch (e) {
      out = { ok: false, error: String((e && e.message) || e) };
    }
    try {
      await fetch(`http://127.0.0.1:${port}/v1/result`, { method: 'POST', headers: { authorization: 'Bearer ' + token, 'content-type': 'application/json' }, body: JSON.stringify({ id: job.id, ...out }) });
    } catch (e) {
      console.error('[ND bridge] không trả được kết quả', e);
    }
  }

  // ── ghép đôi KHÔNG MÃ: công tắc «VS Code» trong khung chat ────────────────────
  // Bật công tắc → xin kết nối tới MỌI cổng VS Code (127.0.0.1:47615–47620); VS Code hiện thẻ «Cho phép / Từ chối» ngay trong khung chat của nó; khi người dùng bấm Cho phép,
  // ta nhận token MỘT lần, lưu rồi nối. Không gõ mã, không mở trang nào. Tắt công tắc = ngừng nối (giữ token để bật lại là nối ngay).
  const pair = { state: 'idle' }; // idle · asking · waiting · denied · expired · not_found · busy · old (VS Code chưa hỗ trợ ghép không mã)
  let pairRun = 0; // số thứ tự lần xin: tắt công tắc giữa chừng thì lần cũ tự dừng

  const post = (port, path, body) => fetch(`http://127.0.0.1:${port}${path}`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body || {}) });
  const cancelAsked = (list) => {
    for (const x of list) if (x && x.id) post(x.port, '/v1/pair/cancel', { id: x.id }).catch(() => {});
  };

  async function requestPairing() {
    const me = ++pairRun;
    pair.state = 'asking';
    const asked = await Promise.all(
      PORTS.map(async (port) => {
        try {
          const r = await post(port, '/v1/pair/request');
          const j = await r.json().catch(() => ({}));
          return r.ok && j.id ? { port, id: j.id } : { port, status: r.status, error: j.error };
        } catch (e) {
          return null; // không có VS Code ở cổng này
        }
      }),
    );
    if (me !== pairRun) return cancelAsked(asked); // công tắc đã tắt trong lúc hỏi
    const live = asked.filter((x) => x && x.id);
    if (!live.length) {
      const any = asked.filter(Boolean);
      pair.state = any.some((x) => x.error === 'busy' || x.error === 'rate_limited') ? 'busy' : any.length ? 'old' : 'not_found';
      await chrome.storage.local.set({ [ON]: false });
      return;
    }
    pair.state = 'waiting';
    const end = Date.now() + 125000;
    while (me === pairRun && Date.now() < end) {
      chrome.runtime.getPlatformInfo(() => void chrome.runtime.lastError); // giữ service worker sống trong lúc chờ người dùng
      let denied = 0;
      let gone = 0;
      for (const x of live) {
        try {
          const r = await fetch(`http://127.0.0.1:${x.port}/v1/pair/status?id=${encodeURIComponent(x.id)}`);
          const j = await r.json();
          if (j.state === 'approved' && j.token) {
            if (me !== pairRun) return;
            await chrome.storage.local.set({ [KEY]: { token: j.token }, [ON]: true });
            cancelAsked(live.filter((y) => y !== x));
            pair.state = 'idle';
            await start();
            return;
          }
          if (j.state === 'denied') denied++;
          else if (j.state === 'expired') gone++;
        } catch (e) {
          gone++;
        }
      }
      if (denied + gone === live.length) {
        pair.state = denied > 0 ? 'denied' : 'expired';
        await chrome.storage.local.set({ [ON]: false });
        return;
      }
      await sleep(1000);
    }
    if (me === pairRun) {
      pair.state = 'expired';
      await chrome.storage.local.set({ [ON]: false });
      cancelAsked(live);
    }
  }

  async function status() {
    const [l, s] = await Promise.all([chrome.storage.local.get([KEY, ALLOW, ON]), chrome.storage.session.get(ALLOW)]);
    const paired = !!(l[KEY] && l[KEY].token);
    const on = l[ON] === undefined ? paired : l[ON] === true; // bản cũ: có token = bật; cài mới chưa ghép = tắt
    return { paired, on, running, connected: connected(), pairing: pair.state, ports: [...loops], allowed: l[ALLOW] || [], session: s[ALLOW] || [] };
  }

  async function toggle(on) {
    if (!on) {
      pairRun++; // dừng lần xin đang chờ (nếu có)
      pair.state = 'idle';
      await chrome.storage.local.set({ [ON]: false });
      stop();
      return status();
    }
    await chrome.storage.local.set({ [ON]: true });
    pair.state = 'idle';
    if (await loadToken()) {
      await start();
      // Đã ghép từ trước: nối ngay. Không nối được trong vài giây (VS Code đóng, hoặc token bị thu hồi ở VS Code) thì xin lại như lần đầu.
      for (let i = 0; i < 16 && !connected(); i++) await sleep(250);
      if (!connected()) void requestPairing();
      return status();
    }
    void requestPairing();
    return status();
  }

  // ── duyệt theo trang (origin) ────────────────────────────────────────────────
  const originOf = (u) => {
    const x = new URL(u);
    if (!/^https?:$/.test(x.protocol)) throw new Error('Chỉ điều khiển được trang http/https.');
    return x.origin;
  };

  // Mẫu quyền của Chrome KHÔNG có cổng: "http://localhost/*" khớp mọi cổng. Việc duyệt của ta vẫn theo origin ĐẦY ĐỦ (kể cả cổng).
  const permPattern = (origin) => {
    const u = new URL(origin);
    return u.protocol + '//' + u.hostname + '/*';
  };

  async function isAllowed(origin) {
    const [s, l] = await Promise.all([chrome.storage.session.get(ALLOW), chrome.storage.local.get(ALLOW)]);
    if (!((s[ALLOW] || []).includes(origin) || (l[ALLOW] || []).includes(origin))) return false;
    return chrome.permissions.contains({ origins: [permPattern(origin)] }); // người dùng có thể đã thu hồi quyền trang ở chrome://extensions
  }

  async function remember(origin, decision) {
    const area = decision === 'always' ? chrome.storage.local : chrome.storage.session;
    const cur = ((await area.get(ALLOW))[ALLOW] || []).filter((o) => o !== origin);
    await area.set({ [ALLOW]: [...cur, origin] });
  }

  function askApproval(origin) {
    if (pending.has(origin)) return pending.get(origin);
    const req = Math.random().toString(36).slice(2);
    let winId;
    let timer;
    const p = new Promise((resolve) => {
      // `decided`: cửa sổ tự đóng ngay sau khi gửi quyết định — việc đóng đó KHÔNG được tính là từ chối.
      const entry = { origin, decided: false, done: (d, reason) => finish(d, reason) };
      const onClose = (id) => {
        if (id === winId && !entry.decided) finish('deny', 'closed');
      };
      const finish = (d, reason) => {
        if (!waiting.has(req)) return;
        waiting.delete(req);
        clearTimeout(timer);
        chrome.windows.onRemoved.removeListener(onClose);
        if (winId !== undefined) chrome.windows.remove(winId).catch(() => {});
        resolve({ d, reason });
      };
      waiting.set(req, entry);
      timer = setTimeout(() => finish('deny', 'timeout'), APPROVE_MS);
      chrome.windows.onRemoved.addListener(onClose);
      chrome.windows
        .create({ url: chrome.runtime.getURL(`bridge-approve.html?req=${req}&origin=${encodeURIComponent(origin)}`), type: 'popup', width: 460, height: 360, focused: true })
        .then((w) => (winId = w.id))
        .catch((e) => finish('deny', 'popup: ' + String((e && e.message) || e)));
    }).finally(() => pending.delete(origin));
    pending.set(origin, p);
    return p;
  }

  async function ensureAccess(url) {
    const origin = originOf(url);
    if (await isAllowed(origin)) return origin;
    const r = await askApproval(origin);
    if (r.d === 'deny') {
      const why =
        r.reason === 'closed' ? 'Cửa sổ xác nhận trong Chrome đã bị đóng mà chưa có quyết định cho ' + origin + '.'
        : r.reason === 'timeout' ? 'Hết thời gian chờ bạn xác nhận cho ' + origin + ' trong Chrome.'
        : r.reason ? 'Chrome không cấp được quyền cho ' + origin + ': ' + r.reason
        : 'Người dùng đã từ chối cho trợ lý điều khiển ' + origin + ' trong Chrome.';
      throw new Error(why);
    }
    return origin;
  }

  // ── thao tác trên tab ────────────────────────────────────────────────────────
  async function getTab(id) {
    if (id !== undefined && id !== null) return chrome.tabs.get(Number(id));
    const [t] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    if (!t) throw new Error('Không có tab nào đang mở.');
    return t;
  }

  async function waitComplete(tabId, ms) {
    const end = Date.now() + ms;
    while (Date.now() < end) {
      const t = await chrome.tabs.get(tabId);
      if (t.status === 'complete') return t;
      await sleep(250);
    }
    return chrome.tabs.get(tabId);
  }

  /** Chạy MỘT hàm trong trang (toàn bộ logic tìm phần tử nằm trong hàm này vì executeScript chỉ chuyển nguyên mã nguồn của hàm). */
  async function inPage(kind, a) {
    const find = (t) => {
      if (t.ref) return document.querySelector('[data-nd-ref="' + CSS.escape(t.ref) + '"]');
      if (t.selector) return document.querySelector(t.selector);
      if (t.text) {
        const q = String(t.text).toLowerCase();
        const els = document.querySelectorAll('a,button,[role=button],[role=link],[role=tab],[role=menuitem],input[type=submit],input[type=button],label,summary');
        return [...els].find((e) => String(e.innerText || e.value || e.getAttribute('aria-label') || '').toLowerCase().includes(q)) || null;
      }
      return null;
    };
    const label = (el) => String(el.innerText || el.value || el.getAttribute('aria-label') || el.getAttribute('placeholder') || el.title || '').trim().replace(/\s+/g, ' ').slice(0, 80);
    const key = (el, k) => {
      const init = { key: k, code: k === 'Enter' ? 'Enter' : k, keyCode: k === 'Enter' ? 13 : 0, which: k === 'Enter' ? 13 : 0, bubbles: true, cancelable: true };
      for (const t of ['keydown', 'keypress', 'keyup']) el.dispatchEvent(new KeyboardEvent(t, init));
    };
    if (kind === 'read') {
      const full = document.body ? document.body.innerText : '';
      const links = [...document.querySelectorAll('a[href]')].map((l) => ({ text: label(l), href: l.href })).filter((l) => l.text && /^https?:/.test(l.href)).slice(0, 100);
      return { url: location.href, title: document.title, text: full.replace(/\n{3,}/g, '\n\n').slice(0, a.max || 40000), truncated: full.length > (a.max || 40000), links, selection: String(getSelection() || '').slice(0, 500) };
    }
    if (kind === 'snapshot') {
      document.querySelectorAll('[data-nd-ref]').forEach((e) => e.removeAttribute('data-nd-ref'));
      const sel = 'a[href],button,input,textarea,select,summary,[role=button],[role=link],[role=textbox],[role=checkbox],[role=menuitem],[role=tab],[contenteditable=""],[contenteditable=true],[onclick]';
      const out = [];
      for (const el of document.querySelectorAll(sel)) {
        if (out.length >= (a.max || 150)) break;
        const r = el.getBoundingClientRect();
        const s = getComputedStyle(el);
        if (r.width < 2 || r.height < 2 || s.visibility === 'hidden' || s.display === 'none' || r.bottom < 0 || r.top > innerHeight * 3) continue;
        const ref = 'e' + (out.length + 1);
        el.setAttribute('data-nd-ref', ref);
        out.push({ ref, tag: el.tagName.toLowerCase(), role: el.getAttribute('role') || undefined, type: el.type || undefined, text: label(el), href: el.tagName === 'A' ? el.href : undefined, disabled: el.disabled || undefined, checked: el.checked === true ? true : undefined, editable: el.isContentEditable || undefined });
      }
      return { url: location.href, title: document.title, elements: out, scroll: { y: Math.round(scrollY), height: document.documentElement.scrollHeight, viewport: innerHeight } };
    }
    if (kind === 'click') {
      const el = find(a);
      if (!el) return { ok: false, error: 'Không thấy phần tử (hãy chạy snapshot rồi dùng ref).' };
      el.scrollIntoView({ block: 'center' });
      if (el.focus) el.focus();
      el.click();
      return { ok: true, clicked: label(el) || el.tagName.toLowerCase() };
    }
    if (kind === 'type') {
      const el = find(a);
      if (!el) return { ok: false, error: 'Không thấy ô nhập (hãy chạy snapshot rồi dùng ref).' };
      el.scrollIntoView({ block: 'center' });
      el.focus();
      if (el.isContentEditable) {
        if (a.clear !== false) document.execCommand('selectAll');
        document.execCommand('insertText', false, a.text);
      } else if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
        const set = Object.getOwnPropertyDescriptor(el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype, 'value').set;
        set.call(el, (a.clear === false ? el.value : '') + a.text);
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
      } else return { ok: false, error: 'Phần tử này không nhập chữ được.' };
      if (a.submit) key(el, 'Enter');
      return { ok: true };
    }
    if (kind === 'key') {
      const el = document.activeElement || document.body;
      key(el, a.key);
      return { ok: true };
    }
    if (kind === 'scroll') {
      if (a.ref || a.selector) {
        const el = find(a);
        if (!el) return { ok: false, error: 'Không thấy phần tử.' };
        el.scrollIntoView({ block: 'center' });
      } else window.scrollBy(0, a.dy || 0);
      return { ok: true, y: Math.round(scrollY) };
    }
    if (kind === 'wait') {
      const end = Date.now() + Math.min(a.ms || 10000, 30000);
      while (Date.now() < end) {
        if (!a.selector || document.querySelector(a.selector)) return { ok: true };
        await new Promise((r) => setTimeout(r, 200));
      }
      return { ok: false, error: 'Hết giờ chờ.' };
    }
    return { ok: false, error: 'Lệnh không hợp lệ.' };
  }

  async function onPage(a, kind) {
    const tab = await getTab(a.tabId);
    if (!tab.url) throw new Error('Không đọc được địa chỉ của tab — cấp quyền "tabs" ở trang cầu nối của extension.');
    await ensureAccess(tab.url);
    const [r] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: inPage, args: [kind, a] });
    if (!r) throw new Error('Không chạy được trên trang này.');
    const res = r.result || {};
    if (res.ok === false) throw new Error(res.error || 'Thao tác thất bại.');
    return { tabId: tab.id, ...res };
  }

  const OPS = {
    ping: async () => ({ v: 1, extension: chrome.runtime.id }),
    'tabs.list': async () => {
      const out = [];
      for (const t of await chrome.tabs.query({})) {
        if (!t.url) {
          out.push({ id: t.id, windowId: t.windowId, active: t.active, restricted: true });
          continue;
        }
        let origin = '';
        try {
          origin = originOf(t.url);
        } catch (e) {
          continue; // chrome://, tab trống…: bỏ qua
        }
        const allowed = await isAllowed(origin);
        out.push(allowed ? { id: t.id, windowId: t.windowId, active: t.active, allowed: true, title: t.title || '', url: t.url } : { id: t.id, windowId: t.windowId, active: t.active, allowed: false, host: new URL(origin).host });
      }
      return out;
    },
    'tab.open': async (a) => {
      const origin = originOf(String(a.url));
      await ensureAccess(origin);
      const tab = await chrome.tabs.create({ url: a.url, active: a.active !== false });
      const t = await waitComplete(tab.id, 30000);
      return { tabId: t.id, url: t.url, title: t.title };
    },
    'tab.activate': async (a) => {
      const tab = await getTab(a.tabId);
      await ensureAccess(tab.url);
      await chrome.tabs.update(tab.id, { active: true });
      await chrome.windows.update(tab.windowId, { focused: true });
      return { tabId: tab.id };
    },
    'tab.close': async (a) => {
      const tab = await getTab(a.tabId);
      await ensureAccess(tab.url);
      await chrome.tabs.remove(tab.id);
      return { closed: tab.id };
    },
    'page.read': (a) => onPage(a, 'read'),
    'page.snapshot': (a) => onPage(a, 'snapshot'),
    'page.click': (a) => onPage(a, 'click'),
    'page.type': (a) => onPage(a, 'type'),
    'page.key': (a) => onPage(a, 'key'),
    'page.scroll': (a) => onPage(a, 'scroll'),
    'page.wait': (a) => onPage(a, 'wait'),
    'page.screenshot': async (a) => {
      const tab = await getTab(a.tabId);
      await ensureAccess(tab.url);
      // Chrome chỉ cho chụp tab khi extension có quyền "mọi trang" (<all_urls>) hoặc activeTab: quyền theo từng trang không đủ. Quyền này TUỲ CHỌN, người dùng bật ở trang cầu nối.
      if (!(await chrome.permissions.contains({ origins: ['<all_urls>'] }))) {
        throw new Error('Chụp màn hình cần quyền "xem mọi trang" (tuỳ chọn) của Chrome. Mở trang cầu nối của extension (chuột phải biểu tượng extension → "Kết nối với VS Code…") và bấm "Cho phép chụp màn hình". Trợ lý vẫn chỉ thao tác được trên các trang bạn đã duyệt. Trong lúc chưa bật, hãy dùng page.snapshot hoặc page.read.');
      }
      await chrome.tabs.update(tab.id, { active: true });
      await chrome.windows.update(tab.windowId, { focused: true });
      await sleep(300);
      const url = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'jpeg', quality: 55 });
      return { tabId: tab.id, mediaType: 'image/jpeg', data: url.slice(url.indexOf(',') + 1) };
    },
  };

  // ── thông điệp từ trang ghép đôi / trang duyệt ───────────────────────────────
  chrome.runtime.onMessage.addListener((m, sender, reply) => {
    if (!m || typeof m !== 'object' || sender.id !== chrome.runtime.id) return;
    if (m.type === 'nd-bridge-start') {
      // Trang ghép đôi bằng mã (bridge.html) vừa ghép xong: người dùng muốn nối → bật công tắc rồi nối.
      pairRun++;
      pair.state = 'idle'; // lỗi cũ của lần xin không mã (không thấy VS Code, bị từ chối…) không còn đúng: ghép bằng mã đã xong
      chrome.storage.local.set({ [ON]: true }).then(start).then((ok) => reply({ ok }));
      return true;
    }
    if (m.type === 'nd-bridge-stop') {
      pairRun++;
      pair.state = 'idle';
      chrome.storage.local.remove([KEY, ON]).then(() => {
        token = '';
        stop();
        reply({ ok: true });
      });
      return true;
    }
    if (m.type === 'nd-bridge-status') {
      status().then(reply);
      return true;
    }
    if (m.type === 'nd-bridge-toggle') {
      toggle(m.on === true).then(reply);
      return true;
    }
    if (m.type === 'nd-bridge-forget') {
      Promise.all([chrome.storage.local.get(ALLOW), chrome.storage.session.get(ALLOW)]).then(async ([l, s]) => {
        await chrome.storage.local.set({ [ALLOW]: (l[ALLOW] || []).filter((o) => o !== m.origin) });
        await chrome.storage.session.set({ [ALLOW]: (s[ALLOW] || []).filter((o) => o !== m.origin) });
        reply({ ok: true });
      });
      return true;
    }
    if (m.type === 'nd-bridge-decision') {
      const w = waiting.get(m.req);
      if (!w) {
        reply({ ok: false });
        return;
      }
      w.decided = true; // từ đây việc cửa sổ đóng lại không còn bị tính là từ chối
      const d = m.decision === 'always' || m.decision === 'once' ? m.decision : 'deny';
      const reason = typeof m.reason === 'string' ? m.reason.slice(0, 300) : undefined;
      (d === 'deny' ? Promise.resolve() : remember(w.origin, d)).then(() => {
        w.done(d, reason);
        reply({ ok: true }); // trang duyệt chờ phản hồi này rồi mới tự đóng
      });
      return true;
    }
  });

  chrome.alarms.onAlarm.addListener((a) => {
    if (a.name === ALARM) void start();
  });
  chrome.contextMenus.onClicked.addListener((info) => {
    if (info.menuItemId === MENU) chrome.tabs.create({ url: chrome.runtime.getURL('bridge.html') });
  });
  const makeMenu = () => chrome.contextMenus.create({ id: MENU, title: 'Kết nối với VS Code…', contexts: ['action'] }, () => void chrome.runtime.lastError);
  makeMenu();
  // background.js gốc gọi contextMenus.removeAll() mỗi khi cài/cập nhật rồi tạo lại menu của nó: tạo lại mục của cầu nối SAU đó,
  // nếu không nó biến mất ngay lần cài đầu tiên. (Trang cầu nối còn mở được qua "Tuỳ chọn" của tiện ích — manifest khai báo options_ui.)
  chrome.runtime.onInstalled.addListener(() => setTimeout(makeMenu, 1500));
  chrome.runtime.onStartup.addListener(() => setTimeout(makeMenu, 1500));
  void start();
})();
