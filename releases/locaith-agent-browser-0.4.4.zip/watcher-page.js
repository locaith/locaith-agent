// Locaith AI — Watcher (phía trang). Chạy trong thế giới ISOLATED của tab đang được theo dõi.
// Chỉ PHÁT HIỆN "có dấu hiệu tin nhắn mới" rồi báo cho service worker; việc đọc/trả lời do trợ lý làm.
(() => {
  'use strict';
  const V = 1;
  if (window.__ndWatchV >= V) return;
  window.__ndWatchV = V;

  const MSG_SEL = [
    '[role="row"]', '[role="listitem"]', '[role="log"]', '[aria-live]',
    '[data-testid*="message" i]', '[data-testid*="conversation" i]',
    '[class*="message" i]', '[class*="msg" i]', '[class*="chat" i]', '[id*="message" i]',
    '[class*="conv" i]', '[class*="unread" i]', '[class*="badge" i]', '[class*="preview" i]', '[class*="thread" i]', '[class*="inbox" i]',
  ].join(',');
  const SKIP_SEL = 'input,textarea,[contenteditable=""],[contenteditable="true"],script,style,noscript';

  let cfg = { signal: 'auto', selector: '', label: '' };
  let alive = true;
  let active = false;
  let lastUnread = unread(document.title);
  let suppressUntil = Date.now() + 4000;
  let timer = null;
  let lastSent = 0;
  const reasons = new Set();
  const samples = [];
  let host = null;
  let pillText = null;

  function unread(t) {
    const m = /^\s*[\(\[]\s*(\d{1,4})\+?\s*[\)\]]/.exec(t || '');
    return m ? +m[1] : 0;
  }

  function shutdown() {
    alive = false;
    active = false;
    try { observer.disconnect(); } catch (e) {}
    try { host && host.remove(); } catch (e) {}
    try { clearTimeout(timer); } catch (e) {}
    document.removeEventListener('keydown', onKey, true);
    document.removeEventListener('click', onClick, true);
  }

  function send(msg, cb) {
    try {
      chrome.runtime.sendMessage(msg, (resp) => {
        if (chrome.runtime.lastError) { if (msg.type === 'nd-watch-event') return; }
        cb && cb(resp);
      });
    } catch (e) {
      shutdown(); // tiện ích vừa được nạp lại: bản chạy cũ tự gỡ
    }
  }

  function buildPill() {
    if (host) return;
    host = document.createElement('div');
    host.style.cssText = 'all:initial;position:fixed;left:12px;bottom:12px;z-index:2147483647;';
    const root = host.attachShadow({ mode: 'closed' });
    root.innerHTML =
      '<style>.p{font:12px/1.2 system-ui,sans-serif;display:flex;gap:8px;align-items:center;' +
      'background:#14121c;color:#ece9f7;border:1px solid #02ebad;border-radius:999px;padding:6px 10px;' +
      'box-shadow:0 2px 10px rgba(0,0,0,.35)}.d{width:8px;height:8px;border-radius:50%;background:#02ebad;' +
      'animation:b 1.6s infinite}@keyframes b{50%{opacity:.25}}button{all:unset;cursor:pointer;color:#fff;' +
      'background:#e5484d;border-radius:999px;padding:3px 9px;font-weight:600}</style>' +
      '<div class="p"><span class="d"></span><span id="t"></span><button id="s">Dừng</button></div>';
    pillText = root.getElementById('t');
    root.getElementById('s').addEventListener('click', (e) => {
      if (!e.isTrusted) return; // chỉ cú bấm thật của người dùng
      send({ type: 'nd-watch-stop' });
    });
    document.documentElement.appendChild(host);
  }

  function applyConfig(c) {
    cfg = { signal: c.signal || 'auto', selector: c.selector || '', label: c.label || 'Locaith AI đang theo dõi trang này' };
    active = true;
    buildPill();
    if (pillText) pillText.textContent = cfg.label;
  }

  function note(kind, sample) {
    if (!alive || !active) return;
    reasons.add(kind);
    if (sample) { samples.push(sample); if (samples.length > 3) samples.shift(); }
    if (!timer) timer = setTimeout(flush, 2000);
  }

  function flush() {
    timer = null;
    if (!alive || !active || reasons.size === 0) return;
    if (Date.now() - lastSent < 5000) { timer = setTimeout(flush, 2000); return; }
    lastSent = Date.now();
    const msg = {
      type: 'nd-watch-event',
      reasons: [...reasons],
      unread: lastUnread,
      sample: samples.slice(),
      title: String(document.title || '').slice(0, 120),
    };
    reasons.clear();
    samples.length = 0;
    send(msg);
  }

  function checkTitle() {
    const u = unread(document.title);
    if (u > lastUnread) note('title', 'Số chưa đọc ' + lastUnread + ' → ' + u);
    lastUnread = u;
  }

  function consider(node) {
    const el = node.nodeType === 1 ? node : node.parentElement;
    if (!el || !el.closest) return;
    if (host && host.contains(el)) return;
    if (el.closest(SKIP_SEL)) return;
    if (cfg.selector) {
      let ok = false;
      try { ok = !!el.closest(cfg.selector); } catch (e) { ok = false; }
      if (!ok) return;
    } else if (!el.closest(MSG_SEL)) return;
    const txt = String(el.innerText || el.textContent || '').trim();
    if (!txt || txt.length > 3000) return;
    note('dom', txt.slice(0, 160));
  }

  const observer = new MutationObserver((muts) => {
    if (!alive || !active) return;
    checkTitle();
    if (cfg.signal === 'title') return;
    if (Date.now() < suppressUntil) return;
    let n = 0;
    for (const m of muts) {
      if (n > 40) break;
      if (m.type === 'childList') {
        for (const a of m.addedNodes) { if (n++ > 40) break; consider(a); }
      } else if (m.type === 'characterData') { n++; consider(m.target); }
    }
  });
  observer.observe(document.documentElement, { childList: true, subtree: true, characterData: true });

  // Người dùng tự gửi tin (Enter / bấm) thì bỏ qua thay đổi DOM ngay sau đó.
  function onKey(e) { if (e.isTrusted && e.key === 'Enter') suppressUntil = Date.now() + 2500; }
  function onClick(e) { if (e.isTrusted) suppressUntil = Date.now() + 2500; }
  document.addEventListener('keydown', onKey, true);
  document.addEventListener('click', onClick, true);

  try {
    chrome.runtime.onMessage.addListener((m) => {
      if (!alive || !m || typeof m !== 'object') return;
      if (m.type === 'nd-watch-config') applyConfig(m);
      else if (m.type === 'nd-watch-rebase') { lastUnread = unread(document.title); suppressUntil = Date.now() + 3000; reasons.clear(); samples.length = 0; }
      else if (m.type === 'nd-watch-bye') shutdown();
    });
  } catch (e) { shutdown(); return; }

  send({ type: 'nd-watch-hello' }, (resp) => {
    if (!resp || resp.stop) { shutdown(); return; }
    applyConfig(resp);
  });
})();
