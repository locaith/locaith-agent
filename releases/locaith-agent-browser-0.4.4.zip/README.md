# Locaith AI cho Chrome / Edge — 0.4.3

Trợ lý AI nằm ở thanh bên của trình duyệt (Claude, ChatGPT, Gemini, DeepSeek, Grok…), đọc và thao tác được trên trang web bạn đang mở.

## Cài đặt (chế độ nhà phát triển)
1. Giải nén tệp .zip vào MỘT thư mục cố định. Đừng xoá thư mục này: Chrome đọc trực tiếp từ đó.
2. Mở `chrome://extensions` (Edge: `edge://extensions`) và bật **Chế độ nhà phát triển**.
3. Bấm **Tải tiện ích đã giải nén** và chọn thư mục vừa giải nén (thư mục chứa `manifest.json`).
4. Ghim biểu tượng Locaith AI lên thanh công cụ.

**Cập nhật:** giải nén bản mới đè vào CÙNG thư mục rồi bấm **Tải lại** ở `chrome://extensions`. Nạp từ một thư mục KHÁC sẽ tạo một tiện ích mới với dữ liệu trống (lịch sử và khoá API nằm theo từng tiện ích; Chrome tính mã tiện ích từ đường dẫn thư mục).

## Có gì mới ở 0.4.3
- **Locaith AI Local (Locaith-v5-flash, Locaith-v5-SI):** mô hình AI của đội ngũ Locaith, miễn phí, cửa sổ ngữ cảnh 1 triệu token. Kết nối trong 3 bước: (1) mở https://locaith.ai/#ext-browser, đăng nhập, đọc thông báo về dữ liệu, đồng ý và bấm **Tạo mã kết nối**; (2) trong tiện ích: **Cài đặt** → mục **Locaith AI Local** → dán mã vào ô «API key của Locaith AI Local» → **Lưu khóa**; (3) bấm tên model ở ô nhập và chọn Locaith-v5-flash (nhanh) hoặc Locaith-v5-SI (suy luận sâu).
  - **Về dữ liệu:** nội dung bạn gửi tới mô hình Locaith (câu hỏi, nội dung trang trợ lý đọc, tệp đính kèm) được gửi tới dịch vụ của Locaith, có thể do đối tác hạ tầng AI của Locaith xử lý, và được lưu (đã che khoá API/mật khẩu/token nhận diện được) để tìm lỗi và cải thiện mô hình. Dùng API riêng (Claude, ChatGPT, Gemini…) thì không qua Locaith. Thu hồi mã kết nối bất cứ lúc nào trong tab «VS Code từ xa» → Thiết bị trên locaith.ai.
  - **Quá tải:** khi hơn 100 người dùng cùng lúc, yêu cầu của bạn được giữ trong hàng chờ ở máy chủ (tối đa khoảng 75 giây) rồi tự chạy; hết hạn thì báo "Đang có nhiều lượt sử dụng" — gửi lại sau ít phút. (Bản VS Code có hàng chờ đếm ngược trong khung chat.)
  - Tiện ích xin thêm quyền truy cập `studio-api.locaith.com` (máy chủ mô hình của Locaith).
- **DeepSeek:** cửa sổ ngữ cảnh đúng 1 triệu token (trước đây bị coi là 128K).
- **Theo dõi trang (Watcher):** chuột phải trang → "Theo dõi tin nhắn trang này…", hoặc nhờ trợ lý bật bằng công cụ `page_watch`. Chế độ: chỉ báo / soạn nháp / tự gửi; có giới hạn lượt và tự tắt sau vài giờ.
- **Cầu nối VS Code:** cho trợ lý trong VS Code (extension Locaith AI Agent từ 0.5.1 trở lên) đọc và điều khiển các trang bạn cho phép.

## Ghép đôi với VS Code
1. Trong VS Code: **Chợ → tab Chrome → Tạo mã ghép đôi**.
2. Trong Chrome: chuột phải biểu tượng Locaith AI → **Kết nối với VS Code…** (hoặc **Tuỳ chọn**) → gõ mã 8 ký tự (hiệu lực 5 phút).
3. Lần đầu trợ lý thao tác trên một trang web, Chrome hiện cửa sổ xin phép riêng cho trang đó. Thu hồi ở chính trang "Kết nối với VS Code".

- Cầu nối chỉ nói chuyện với VS Code trên máy của bạn (127.0.0.1); trang web không truy cập được. Mã ghép đôi dùng một lần.
- Nội dung trang trợ lý đọc được sẽ gửi tới nhà cung cấp AI bạn đang dùng: chỉ cho phép những trang bạn thoải mái chia sẻ.
- Chụp màn hình cần bật thêm quyền "xem mọi trang" (tuỳ chọn) ở trang cầu nối.

## Giấy phép
Miễn phí sử dụng theo Giấy phép Freeware của Locaith — xem `LICENSE.txt` (bản tiếng Anh là bản có hiệu lực). Thành phần bên thứ ba: `THIRD_PARTY_NOTICES.md`.

## 0.4.4

- **Công tắc «VS Code» ngay trong khung chat**: bật để trợ lý điều khiển Chrome từ VS Code — KHÔNG cần nhập mã. VS Code hiện thẻ «Cho phép / Từ chối» trong khung chat của nó; bấm Cho phép là nối. Tắt là ngừng nối (giữ ghép đôi để bật lại nối ngay). Cần extension Locaith AI trong VS Code 0.6.1 trở lên.
- Logo Locaith «Lo» thay biểu tượng cũ ở tiêu đề, màn chào và ô chọn model (model Locaith luôn có logo); chỉ báo «đang làm việc» là chính logo.
