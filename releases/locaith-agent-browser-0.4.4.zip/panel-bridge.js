// Locaith AI — công tắc «VS Code» ngay trên thanh tiêu đề khung chat của extension Chrome.
// MỘT cú bấm bật/tắt, KHÔNG gõ mã: bật → xin kết nối, VS Code hiện thẻ «Cho phép / Từ chối» trong khung chat của nó → bấm Cho phép là nối. Tắt → ngừng nối (giữ ghép đôi để bật lại là nối ngay).
// Nạp trước panel.js; panel.js (đã vá một chỗ ở thanh tiêu đề) gắn phần tử `ref` vào `window.__lcBridgeRef`. Toàn bộ logic nằm ở đây (JS thường, không phải mã đã nén) và nói chuyện với bridge-sw.js
// bằng chrome.runtime.sendMessage — không đụng vào trạng thái của giao diện chính. Ngôn ngữ theo khung chat (document.documentElement.lang, do panel.js đặt từ cài đặt), không theo trình duyệt.
(() => {
  'use strict';
  const DICT = {
    vi: {
      label: 'VS Code',
      off: 'Kết nối với VS Code: đang tắt. Bấm để bật — không cần nhập mã; VS Code sẽ hiện thẻ «Cho phép» để bạn xác nhận.',
      asking: 'Đang tìm VS Code…',
      waiting: 'Chờ bạn bấm Cho phép trong VS Code',
      waitingTitle: 'Mở VS Code → khung chat Locaith AI → bấm «Cho phép». Bấm vào đây để huỷ.',
      connected: 'Đã kết nối với VS Code. Bấm để tắt.',
      searching: 'Đang tìm VS Code…',
      searchingTitle: 'Đã ghép đôi nhưng chưa thấy VS Code. Hãy mở VS Code có extension Locaith AI. Bấm để tắt.',
      denied: 'Đã từ chối',
      deniedTitle: 'Bạn đã từ chối trong VS Code. Bấm để thử lại.',
      expired: 'Hết hạn — thử lại',
      expiredTitle: 'Chưa ai bấm Cho phép trong VS Code. Bấm để thử lại.',
      not_found: 'Không thấy VS Code',
      not_foundTitle: 'Không có VS Code nào đang mở với extension Locaith AI (hoặc cầu nối Chrome đã tắt trong cài đặt). Mở VS Code rồi bấm để thử lại.',
      busy: 'VS Code đang bận',
      busyTitle: 'VS Code đang chờ bạn quyết định một yêu cầu khác. Thử lại sau ít phút.',
      old: 'Cần cập nhật VS Code',
      oldTitle: 'Extension Locaith AI trong VS Code chưa hỗ trợ kết nối không cần mã — hãy cập nhật lên 0.6.1 trở lên. Bấm để thử lại.',
    },
    en: {
      label: 'VS Code',
      off: 'Connect to VS Code: off. Click to turn on — no code to type; VS Code shows an “Allow” card for you to confirm.',
      asking: 'Looking for VS Code…',
      waiting: 'Waiting for you to click Allow in VS Code',
      waitingTitle: 'Open VS Code → the Locaith AI chat → click “Allow”. Click here to cancel.',
      connected: 'Connected to VS Code. Click to turn off.',
      searching: 'Looking for VS Code…',
      searchingTitle: 'Paired, but VS Code is not reachable. Open VS Code with the Locaith AI extension. Click to turn off.',
      denied: 'Denied',
      deniedTitle: 'You denied it in VS Code. Click to try again.',
      expired: 'Expired — try again',
      expiredTitle: 'Nobody clicked Allow in VS Code. Click to try again.',
      not_found: 'VS Code not found',
      not_foundTitle: 'No VS Code with the Locaith AI extension is open (or the Chrome bridge is switched off in its settings). Open VS Code and click to try again.',
      busy: 'VS Code is busy',
      busyTitle: 'VS Code is waiting for you to decide another request. Try again in a minute.',
      old: 'Update VS Code',
      oldTitle: 'The Locaith AI extension in VS Code does not support code-less connection yet — update to 0.6.1 or later. Click to try again.',
    },
  };
  const dict = () => (/^en/i.test(document.documentElement.lang || '') ? DICT.en : DICT.vi);

  const ICON = '<svg class="hdr-bridge-ico" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M8 7l-5 5 5 5"/><path d="M16 7l5 5-5 5"/><path d="M14 4l-4 16"/></svg>';
  let btn = null;
  let timer = 0;
  let last = null;

  const send = (msg) =>
    new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(msg, (r) => {
          void chrome.runtime.lastError;
          resolve(r || null);
        });
      } catch (e) {
        resolve(null);
      }
    });

  /** Từ trạng thái của bridge-sw.js ra: nhãn, chú giải, giai đoạn (off · warn · ok · bad) của công tắc. */
  function view(st) {
    const T = dict();
    if (!st) return { tone: 'off', on: false, label: T.label, title: T.off };
    const p = st.pairing;
    if (st.on && st.connected && p !== 'asking' && p !== 'waiting') return { tone: 'ok', on: true, label: T.label, title: T.connected }; // đã nối thì lỗi cũ không còn nghĩa
    if (p === 'asking') return { tone: 'warn', on: true, label: T.asking, title: T.waitingTitle };
    if (p === 'waiting') return { tone: 'warn', on: true, label: T.waiting, title: T.waitingTitle };
    if (p === 'denied') return { tone: 'bad', on: false, label: T.denied, title: T.deniedTitle };
    if (p === 'expired') return { tone: 'bad', on: false, label: T.expired, title: T.expiredTitle };
    if (p === 'not_found') return { tone: 'bad', on: false, label: T.not_found, title: T.not_foundTitle };
    if (p === 'busy') return { tone: 'bad', on: false, label: T.busy, title: T.busyTitle };
    if (p === 'old') return { tone: 'bad', on: false, label: T.old, title: T.oldTitle };
    if (!st.on) return { tone: 'off', on: false, label: T.label, title: T.off };
    return { tone: 'warn', on: true, label: T.searching, title: T.searchingTitle };
  }

  function render(st) {
    last = st;
    if (!btn) return;
    const v = view(st);
    btn.className = 'hdr-bridge is-' + v.tone + (v.on ? ' is-on' : '');
    btn.setAttribute('aria-checked', v.on ? 'true' : 'false');
    btn.title = v.title;
    btn.setAttribute('aria-label', v.label + '. ' + v.title);
    btn.querySelector('.hdr-bridge-label').textContent = v.label;
  }

  const refresh = async () => render(await send({ type: 'nd-bridge-status' }));

  async function onClick() {
    const v = view(last);
    btn.disabled = true;
    render(await send({ type: 'nd-bridge-toggle', on: !v.on }));
    btn.disabled = false;
    void refresh();
  }

  function mount(el) {
    if (!el) {
      // phần tử bị gỡ (đổi màn hình): dừng nhịp làm mới
      clearInterval(timer);
      timer = 0;
      btn = null;
      return;
    }
    btn = document.createElement('button');
    btn.type = 'button';
    btn.setAttribute('role', 'switch');
    btn.innerHTML = ICON + '<span class="hdr-bridge-label"></span><span class="hdr-bridge-dot" aria-hidden="true"></span>';
    btn.addEventListener('click', () => void onClick());
    el.replaceChildren(btn);
    render(last);
    void refresh();
    clearInterval(timer);
    timer = setInterval(() => {
      if (document.visibilityState === 'visible') void refresh();
    }, 1500);
  }

  window.__lcBridgeRef = mount;
})();
