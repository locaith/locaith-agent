# Locaith AI cho Chrome / Edge — 0.4.2

Trợ lý AI nằm ở thanh bên của trình duyệt (Claude, ChatGPT, Gemini, DeepSeek, Grok…), đọc và thao tác được trên trang web bạn đang mở.

## Cài đặt (chế độ nhà phát triển)
1. Giải nén tệp .zip vào MỘT thư mục cố định. Đừng xoá thư mục này: Chrome đọc trực tiếp từ đó.
2. Mở `chrome://extensions` (Edge: `edge://extensions`) và bật **Chế độ nhà phát triển**.
3. Bấm **Tải tiện ích đã giải nén** và chọn thư mục vừa giải nén (thư mục chứa `manifest.json`).
4. Ghim biểu tượng Locaith AI lên thanh công cụ.

**Cập nhật:** giải nén bản mới đè vào CÙNG thư mục rồi bấm **Tải lại** ở `chrome://extensions`. Nạp từ một thư mục KHÁC sẽ tạo một tiện ích mới với dữ liệu trống (lịch sử và khoá API nằm theo từng tiện ích; Chrome tính mã tiện ích từ đường dẫn thư mục).

## Có gì mới ở 0.4.2
- **Theo dõi trang (Watcher):** chuột phải trang → "Theo dõi tin nhắn trang này…", hoặc nhờ trợ lý bật bằng công cụ `page_watch`. Chế độ: chỉ báo / soạn nháp / tự gửi; có giới hạn lượt và tự tắt sau vài giờ.
- **Cầu nối VS Code:** cho trợ lý trong VS Code (extension Locaith AI Agent từ 0.5.1 trở lên) đọc và điều khiển các trang bạn cho phép.

## Ghép đôi với VS Code
1. Trong VS Code: **Chợ → tab Chrome → Tạo mã ghép đôi**.
2. Trong Chrome: chuột phải biểu tượng Locaith AI → **Kết nối với VS Code…** (hoặc **Tuỳ chọn**) → gõ mã 8 ký tự (hiệu lực 5 phút).
3. Lần đầu trợ lý thao tác trên một trang web, Chrome hiện cửa sổ xin phép riêng cho trang đó. Thu hồi ở chính trang "Kết nối với VS Code".

- Cầu nối chỉ nói chuyện với VS Code trên máy của bạn (127.0.0.1); trang web không truy cập được. Mã ghép đôi dùng một lần.
- Nội dung trang trợ lý đọc được sẽ gửi tới nhà cung cấp AI bạn đang dùng: chỉ cho phép những trang bạn thoải mái chia sẻ.
- Chụp màn hình cần bật thêm quyền "xem mọi trang" (tuỳ chọn) ở trang cầu nối.

## Giấy phép
Miễn phí sử dụng theo Giấy phép Freeware của Locaith — xem `LICENSE.txt` (bản tiếng Anh là bản có hiệu lực). Thành phần bên thứ ba: `THIRD_PARTY_NOTICES.md`.
